package Day15.다형성_73_자동차;

public class Truck {

	int load;
}
