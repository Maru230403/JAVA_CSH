package Day15.다형성_73_자동차;

public class Sedan extends Car {

	public void sedan() {
		System.out.println("Sedan 객체 생성자 호출");
	}

}
