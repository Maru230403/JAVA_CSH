package Day14.상속실습_도형넓이_override;

public class Shape {
	protected float area;
	public void printArea() {
		System.out.println("도형의 넓이는 "+this.area+" 입니다.");
	}

}
