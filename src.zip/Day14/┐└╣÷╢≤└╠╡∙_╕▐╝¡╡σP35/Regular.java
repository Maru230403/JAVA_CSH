package Day14.오버라이딩_메서드P35;

public class Regular extends Employee {

	public Regular(String name, int payPerMonth, int commision) {
		super(name, payPerMonth, commision);
	}
	
}
